
package com.ads.lojinha;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    @Query(value = "SELECT * FROM cliente WHERE ativo=1 AND email=:email AND senha=:senha", nativeQuery = true)
    Optional<Cliente> fazerLogin(
        @Param("email") String email,
        @Param("senha") String senha
    );

    @Modifying
    @Transactional
    @Query(value = "UPDATE cliente SET senha=:senhaTemp, ativo=0 WHERE email=:email", nativeQuery = true)
    int resetarSenha(
        @Param("senhaTemp") String senhaTemp,
        @Param("email") String email
    );

    @Modifying
    @Transactional
    @Query(value = "UPDATE cliente SET senha=:novaSenha, ativo=1 WHERE documento=:documento AND email=:email", nativeQuery = true)
    int alterarSenha(
        @Param("novaSenha") String novaSenha,
        @Param("documento") String documento,
        @Param("email") String email
    );
}

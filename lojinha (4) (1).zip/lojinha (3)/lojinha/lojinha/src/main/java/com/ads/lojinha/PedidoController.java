
package com.ads.lojinha;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
public class PedidoController {

    @Autowired
    PedidoRepository bd;

    @GetMapping("/api/pedido/{codigo}")
    public Pedido retorna(@PathVariable("codigo") int id) {
        return bd.findById(id).orElse(new Pedido());
    }

    @GetMapping("/api/pedido/cliente/{codigoCliente}")
    public List<Pedido> listarPorCliente(
        @PathVariable("codigoCliente") int codigoCliente
    ) {
        return bd.findByCodigoCliente(codigoCliente);
    }

    @PostMapping("/api/pedido")
    public String gravar(@RequestBody Pedido obj) {
        if (obj.getItens() != null) {
            obj.getItens().forEach(item -> item.setPedido(obj));
        }

        bd.save(obj);
        return "Pedido gravado com sucesso! " + obj.getCodigoPedido();
    }

    @PutMapping("/api/pedido")
    public String alterar(@RequestBody Pedido obj) {
        if (bd.existsById(obj.getCodigoPedido())) {
            if (obj.getItens() != null) {
                obj.getItens().forEach(item -> item.setPedido(obj));
            }
            bd.save(obj);
            return "Pedido alterado com sucesso! " + obj.getCodigoPedido();
        }

        return "Pedido não encontrado!";
    }

    @DeleteMapping("/api/pedido/{codigo}")
    public String apagar(@PathVariable("codigo") int id) {
        bd.deleteById(id);
        return "Pedido removido com sucesso!";
    }
}

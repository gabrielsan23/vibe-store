
package com.ads.lojinha;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
public class ClienteController {

    @Autowired
    ClienteRepository bd;

    @GetMapping("/api/cliente/{codigo}")
    public Cliente retorna(@PathVariable("codigo") int id) {
        return bd.findById(id).orElse(new Cliente());
    }

    @PostMapping("/api/cliente")
    public String gravar(@RequestBody Cliente obj) {
        bd.save(obj);
        return "Cliente gravado com sucesso! " + obj.getCodigo();
    }

    @PutMapping("/api/cliente")
    public String alterar(@RequestBody Cliente obj) {
        if (bd.existsById(obj.getCodigo())) {
            bd.save(obj);
            return "Cliente alterado com sucesso! " + obj.getCodigo();
        }
        return "Cliente não encontrado!";
    }

    @DeleteMapping("/api/cliente/{codigo}")
    public String apagar(@PathVariable("codigo") int id) {
        bd.deleteById(id);
        return "Cliente removido com sucesso!";
    }

    @PostMapping("/api/cliente/login")
    public Cliente fazerLogin(@RequestBody Cliente obj) {
        Optional<Cliente> cliente = bd.fazerLogin(obj.getEmail(), obj.getSenha());
        return cliente.orElse(new Cliente());
    }

    @PatchMapping("/api/cliente/resetarSenha")
    public String resetarSenha(@RequestBody Cliente obj) {
        bd.resetarSenha("Senha1234", obj.getEmail());
        return "Sua senha foi reiniciada, verifique o seu email!";
    }

    @PatchMapping("/api/cliente/alterarSenha")
    public String alterarSenha(@RequestBody Cliente obj) {
        bd.alterarSenha(obj.getSenha(), obj.getDocumento(), obj.getEmail());
        return "Sua senha foi alterada, verifique o seu email!";
    }
}

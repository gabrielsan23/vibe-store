
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Produto } from '../vitrine/produto';

import { PedidoService } from '../services/pedido.service';
import { Pedido } from '../services/pedido.model';

@Component({
  imports: [CommonModule],
  selector: 'app-cesta',
  styleUrl: './cesta.css',
  templateUrl: './cesta.html',
})
export class Cesta implements OnInit {

  constructor(private pedidoService: PedidoService) {}

  static produtos: Produto[] = [];

  produtos: Produto[] = [];
  quantidades: number[] = [];

  ngOnInit(): void {
    Cesta.produtos = JSON.parse(
      localStorage.getItem('cesta') || '[]'
    );

    this.produtos = Cesta.produtos;
    this.quantidades = this.produtos.map(() => 1);
  }

  aumentar(index: number): void {
    this.quantidades[index]++;
  }

  diminuir(index: number): void {
    if (this.quantidades[index] > 1) {
      this.quantidades[index]--;
    }
  }

  limparCesta(): void {
    Cesta.produtos = [];
    this.produtos = [];
    this.quantidades = [];

    localStorage.removeItem('cesta');
  }

  calcularTotal(): string {
    let total = 0;

    for (let i = 0; i < this.produtos.length; i++) {
      const valor = Number(
        this.produtos[i].preco_atual
          .replace('R$', '')
          .replace('.', '')
          .replace(',', '.')
          .trim()
      );

      total += valor * this.quantidades[i];
    }

    return total.toFixed(2).replace('.', ',');
  }

  finalizarCompra(): void {
    if (this.produtos.length === 0) {
      alert('Sua cesta está vazia!');
      return;
    }

    const dadosCliente = localStorage.getItem('clienteLogado');

    if (!dadosCliente) {
      alert('Você precisa fazer login antes de finalizar a compra!');
      return;
    }

    const cliente = JSON.parse(dadosCliente);
    const hoje = new Date();

    const dataPedido =
      `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}-${String(hoje.getDate()).padStart(2, '0')}`;

    const itens = this.produtos.map((produto, index) => {
      const valor = Number(
        produto.preco_atual
          .replace('R$', '')
          .replace('.', '')
          .replace(',', '.')
          .trim()
      );

      return {
        codigoProduto: produto.codigo,
        quantidade: this.quantidades[index],
        valor
      };
    });

    const pedido: Pedido = {
      valorTotal: Number(this.calcularTotal().replace(',', '.')),
      entrega: '',
      obs: '',
      dataPedido,
      codigoCliente: cliente.codigo,
      itens
    };

    this.pedidoService.gravar(pedido).subscribe({
      next: (resposta) => {
        alert('Pedido realizado com sucesso!');
        console.log('Pedido gravado:', resposta);
        this.limparCesta();
      },
      error: (erro) => {
        console.error('Erro ao finalizar pedido:', erro);
        alert('Não foi possível finalizar sua compra.');
      }
    });
  }
}

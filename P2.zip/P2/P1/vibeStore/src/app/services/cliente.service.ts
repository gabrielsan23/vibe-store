
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cliente } from './cliente.model';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  private apiUrl = 'http://localhost:8081/api/cliente';

  constructor(private http: HttpClient) {}

  cadastrar(cliente: Cliente): Observable<string> {
    return this.http.post(this.apiUrl, cliente, {
      responseType: 'text'
    });
  }

  login(email: string, senha: string): Observable<Cliente> {
    return this.http.post<Cliente>(
      `${this.apiUrl}/login`,
      { email, senha }
    );
  }

  buscar(codigo: number): Observable<Cliente> {
    return this.http.get<Cliente>(
      `${this.apiUrl}/${codigo}`
    );
  }

  alterar(cliente: Cliente): Observable<string> {
    return this.http.put(this.apiUrl, cliente, {
      responseType: 'text'
    });
  }

  apagar(codigo: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${codigo}`, {
      responseType: 'text'
    });
  }

  resetarSenha(email: string): Observable<string> {
    return this.http.patch(
      `${this.apiUrl}/resetarSenha`,
      { email },
      { responseType: 'text' }
    );
  }

  alterarSenha(
    senha: string,
    documento: string,
    email: string
  ): Observable<string> {
    return this.http.patch(
      `${this.apiUrl}/alterarSenha`,
      { senha, documento, email },
      { responseType: 'text' }
    );
  }
}


export interface Cliente {
  codigo?: number;
  nome: string;
  telefone: string;
  documento: string;
  senha: string;
  logradouro?: string;
  email: string;
  ativo?: number;
}

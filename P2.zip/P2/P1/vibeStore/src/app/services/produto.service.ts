import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Produto } from './produto.model';

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {

  private apiUrl = 'http://localhost:8081/api/produto';

  constructor(private http: HttpClient) {}

  buscar(codigo: number): Observable<Produto> {
    return this.http.get<Produto>(
      `${this.apiUrl}/${codigo}`
    );
  }

  listar(): Observable<Produto[]> {
    return this.http.get<Produto[]>(
      'http://localhost:8081/api/produtos'
    );
  }

  carregarVitrine(): Observable<Produto[]> {
    return this.http.get<Produto[]>(
      `${this.apiUrl}/vitrine`
    );
  }

  gravar(produto: Produto): Observable<string> {
    return this.http.post(
      this.apiUrl,
      produto,
      { responseType: 'text' }
    );
  }

  alterar(produto: Produto): Observable<string> {
    return this.http.put(
      this.apiUrl,
      produto,
      { responseType: 'text' }
    );
  }

  apagar(codigo: number): Observable<string> {
    return this.http.delete(
      `${this.apiUrl}/${codigo}`,
      { responseType: 'text' }
    );
  }

  pesquisar(termo: string): Observable<Produto[]> {
    return this.http.get<Produto[]>(
      `${this.apiUrl}/busca/${encodeURIComponent(termo)}`
    );
  }

}
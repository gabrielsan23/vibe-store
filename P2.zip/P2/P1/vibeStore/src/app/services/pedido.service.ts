
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pedido } from './pedido.model';

@Injectable({
  providedIn: 'root'
})
export class PedidoService {

  private apiUrl = 'http://localhost:8081/api/pedido';

  constructor(private http: HttpClient) { }

  buscar(codigo: number): Observable<Pedido> {
    return this.http.get<Pedido>(`${this.apiUrl}/${codigo}`);
  }

  listarPorCliente(codigoCliente: number): Observable<Pedido[]> {
    return this.http.get<Pedido[]>(
      `${this.apiUrl}/cliente/${codigoCliente}`
    );
  }

  gravar(pedido: Pedido): Observable<string> {
    return this.http.post(this.apiUrl, pedido, {
      responseType: 'text'
    });
  }

  alterar(pedido: Pedido): Observable<string> {
    return this.http.put(this.apiUrl, pedido, {
      responseType: 'text'
    });
  }

  apagar(codigo: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${codigo}`, {
      responseType: 'text'
    });
  }
}

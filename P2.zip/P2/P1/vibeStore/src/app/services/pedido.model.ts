
export interface ItemPedido {
  codigoProduto: number;
  quantidade: number;
  valor: number;
}

export interface Pedido {
  codigoPedido?: number;
  valorTotal: number;
  entrega: string;
  obs: string;
  dataPedido: string;
  codigoCliente: number;
  itens: ItemPedido[];
}

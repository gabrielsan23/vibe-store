
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ClienteService } from '../services/cliente.service';
import { Cliente } from '../services/cliente.model';

@Component({
  imports: [FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

  email: string = '';
  senha: string = '';

  constructor(private clienteService: ClienteService) {}

  entrar(): void {

    this.clienteService.login(this.email, this.senha).subscribe({

      next: (cliente: Cliente) => {

        if (cliente.codigo && cliente.codigo > 0) {

          const clienteLogado = {
            codigo: cliente.codigo,
            nome: cliente.nome,
            email: cliente.email,
            logradouro: cliente.logradouro
          };

          localStorage.setItem(
            'clienteLogado',
            JSON.stringify(clienteLogado)
          );

          alert('Login realizado com sucesso!');

          console.log('Cliente autenticado:', clienteLogado);

        } else {

          alert('E-mail ou senha incorretos!');

        }

      },

      error: (erro) => {

        console.error('Erro ao realizar login:', erro);
        alert('Não foi possível realizar o login.');

      }

    });

  }

}

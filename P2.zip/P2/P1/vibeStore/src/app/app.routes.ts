
import { Routes } from '@angular/router';
import { Vitrine } from './vitrine/vitrine';
import { Detalhe } from './detalhe/detalhe';
import { Busca } from './busca/busca';
import { Cesta } from './cesta/cesta';
import { Login } from './login/login';
import { Esqueci } from './esqueci/esqueci';
import { CadastroComponent } from './cadastro/cadastro';
import { Sobre } from './sobre/sobre';
import { Contato } from './contato/contato';
import { Pedidos } from './pedidos/pedidos';

export const routes: Routes = [
    {path:'vitrine', redirectTo: 'todos', pathMatch: 'full'},
    {path: 'todos', component:Vitrine},
    {path:'feminino', component:Vitrine},
    {path:'masculino', component:Vitrine},
    {path:'promocoes', component:Vitrine},
    {path:'novidades', component:Vitrine},
    {path:'detalhe/:codigo', component:Detalhe},
    {path:'busca', component:Busca},
    {path:'cesta', component:Cesta},
    {path:'pedidos', component:Pedidos},
    {path:'login', component:Login},
    {path:"esqueci", component:Esqueci},
    {path:"cadastro", component:CadastroComponent},
    {path:"sobre", component:Sobre},
    {path:"contato", component:Contato},
    { path: '', redirectTo: 'todos', pathMatch: 'full' },
];

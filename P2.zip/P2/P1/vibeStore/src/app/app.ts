import { Component, signal } from '@angular/core';
import { Router, RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    FormsModule
  ],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {

  termoPesquisa: string = '';

  constructor(public router: Router) {}

  pesquisar() {

  const busca = this.termoPesquisa.trim();

  this.router.navigate(
    ['/todos'],
    {
      queryParams: {
        busca: busca || null
      }
    }
  );

}

  protected readonly title = signal('vibeStore');

}
import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import {
  ActivatedRoute,
  RouterLink
} from '@angular/router';

import { CommonModule } from '@angular/common';
import { combineLatest } from 'rxjs';

import { Produto } from './produto';
import { Produto as ProdutoApi } from '../services/produto.model';
import { ProdutoService } from '../services/produto.service';

@Component({
  imports: [CommonModule, RouterLink],
  selector: 'app-vitrine',
  styleUrl: './vitrine.css',
  templateUrl: './vitrine.html',
})
export class Vitrine implements OnInit {

  categoria: string = '';
  produtosExibidos: Produto[] = [];
  tituloVitrine: string = 'Todos os Produtos';
  mensagem: string = '';
  carregando: boolean = false;

  static lista: Produto[] = [];


  constructor(
    private route: ActivatedRoute,
    private produtoService: ProdutoService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {

    combineLatest([
      this.route.url,
      this.route.queryParams
    ]).subscribe(([url, params]) => {

      this.categoria = url[0]?.path || 'todos';

      const busca = String(
        params['busca'] || ''
      ).trim();

      this.carregarProdutos(busca);

    });

  }

  private carregarProdutos(busca: string = ''): void {

    this.mensagem = '';
    this.carregando = true;

    this.cdr.markForCheck();

    // Define o título da vitrine.
    if (busca) {

      this.tituloVitrine = `Busca: ${busca}`;

    } else if (this.categoria === 'feminino') {

      this.tituloVitrine = 'Moda Feminina';

    } else if (this.categoria === 'masculino') {

      this.tituloVitrine = 'Moda Masculina';

    } else if (this.categoria === 'promocoes') {

      this.tituloVitrine = 'Promoções';

    } else if (this.categoria === 'novidades') {

      this.tituloVitrine = 'Produtos em Destaque';

    } else {

      this.tituloVitrine = 'Todos os Produtos';

    }

    // Seleciona o endpoint.
    const requisicao = busca
      ? this.produtoService.pesquisar(busca)
      : this.categoria === 'novidades'
        ? this.produtoService.carregarVitrine()
        : this.produtoService.listar();

    requisicao.subscribe({

      next: (dados: ProdutoApi[]) => {

        let produtos = dados ?? [];

        console.log('[VITRINE] Dados recebidos:', dados);

        // Filtros de categoria e promoção.
        if (!busca) {

          if (this.categoria === 'feminino') {

            produtos = produtos.filter(produto =>
              produto.categoria?.toUpperCase() === 'FEMININO'
            );

          } else if (this.categoria === 'masculino') {

            produtos = produtos.filter(produto =>
              produto.categoria?.toUpperCase() === 'MASCULINO'
            );

          } else if (this.categoria === 'promocoes') {

            produtos = produtos.filter(produto =>
              produto.valorPromo > 0 &&
              produto.valorPromo < produto.valor
            );

          }

        }

        // Converte os produtos da API.
        const convertidos = produtos.map(produto =>
          this.converterProduto(produto)
        );

        this.produtosExibidos = convertidos;

        console.log(
          '[VITRINE] Produtos exibidos:',
          this.produtosExibidos
        );

        if (convertidos.length === 0) {

          this.mensagem = 'Nenhum produto encontrado.';

        }

        this.carregando = false;

        this.cdr.markForCheck();

      },

      error: (erro) => {

        console.error(
          'Erro ao carregar produtos:',
          erro
        );

        this.produtosExibidos = [];

        this.mensagem =
          'Não foi possível carregar os produtos. Verifique a conexão com a API.';

        this.carregando = false;

        this.cdr.markForCheck();

      }

    });

  }

  // Converte o produto do Java para o modelo visual.
  private converterProduto(dado: ProdutoApi): Produto {

    const valorOriginal = Number(dado.valor || 0);

    const valorPromo = Number(dado.valorPromo || 0);

    const emPromocao =
      valorPromo > 0 &&
      valorPromo < valorOriginal;

    const codigo = dado.codigo || 0;

    const imagemInformada = dado.imagem?.trim();

    const imagem = imagemInformada
      ? imagemInformada.startsWith('/')
        ? imagemInformada
        : `/${imagemInformada}`
      : this.obterImagem(codigo);

    return {

      codigo,

      tag: emPromocao
        ? 'PROMOÇÃO'
        : dado.destaque > 0
          ? 'NOVO'
          : null,

      categoria: (dado.categoria || 'PRODUTO').toUpperCase(),

      nome: dado.nome,

      preco_atual: this.formatarPreco(
        emPromocao ? valorPromo : valorOriginal
      ),

      preco_original: emPromocao
        ? this.formatarPreco(valorOriginal)
        : null,

      imagem,

      descricao: dado.descritivo

    };

  }

  // Formata os valores monetários.
  private formatarPreco(valor: number): string {

    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);

  }

  // Imagem alternativa caso não exista imagem no banco.
  private obterImagem(codigo: number): string {

    if (codigo >= 1 && codigo <= 8) {
      return `/${codigo}.avif`;
    }

    return '/1.avif';

  }

}
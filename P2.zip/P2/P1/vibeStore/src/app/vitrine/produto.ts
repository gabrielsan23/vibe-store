
export class Produto {
    codigo: number = 0;
    tag: string | null = null;
    categoria: string = "";
    nome: string = "";
    preco_atual: string = "";
    preco_original: string | null = null;
    imagem: string = "";
    descricao: string = "";
}

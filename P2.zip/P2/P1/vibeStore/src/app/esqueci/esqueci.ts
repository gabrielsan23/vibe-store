
import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { ClienteService } from '../services/cliente.service';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-esqueci',
  styleUrl: './esqueci.css',
  templateUrl: './esqueci.html',
})
export class Esqueci {

  email: string = '';
  mensagem: string = '';
  erro: boolean = false;
  carregando: boolean = false;

  constructor(
    private clienteService: ClienteService,
    private cdr: ChangeDetectorRef
  ) {}

  recuperarSenha(): void {
    if (!this.email.trim()) {
      this.mensagem = 'Informe seu e-mail.';
      this.erro = true;
      return;
    }

    this.carregando = true;
    this.mensagem = '';

    this.clienteService.resetarSenha(this.email.trim())
      .pipe(
        finalize(() => {
          this.carregando = false;
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (resposta) => {
          this.mensagem = resposta;
          this.erro = false;
        },
        error: (erro) => {
          console.error('Erro ao recuperar senha:', erro);
          this.mensagem = 'Não foi possível recuperar a senha.';
          this.erro = true;
        }
      });
  }
}


import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { NgxMaskDirective } from 'ngx-mask';

import { ClienteService } from '../services/cliente.service';
import { Cliente } from '../services/cliente.model';

@Component({
  selector: 'app-cadastro',
  imports: [
    FormsModule,
    NgxMaskDirective
  ],
  templateUrl: './cadastro.html',
  styleUrl: './cadastro.css'
})
export class CadastroComponent {

  constructor(private clienteService: ClienteService) {}

  nome: string = '';
  email: string = '';
  senha: string = '';
  confirmarSenha: string = '';
  cpf: string = '';
  telefone: string = '';

  mostrarSenha: boolean = false;
  mostrarConfirmarSenha: boolean = false;

  carregando: boolean = false;

  senhasIguais(): boolean {
    return !!this.senha &&
      !!this.confirmarSenha &&
      this.senha === this.confirmarSenha;
  }

  cadastrar(form: NgForm): void {

    if (form.invalid || !this.senhasIguais()) {
      form.control.markAllAsTouched();
      return;
    }

    const cliente: Cliente = {
      nome: this.nome.trim(),
      email: this.email.trim(),
      senha: this.senha,
      documento: this.cpf.replace(/\D/g, ''),
      telefone: this.telefone.replace(/\D/g, ''),
      ativo: 1
    };

    this.carregando = true;

    this.clienteService.cadastrar(cliente).subscribe({

      next: (resposta) => {
        alert('Cadastro realizado com sucesso!');
        console.log('Cliente cadastrado:', resposta);

        form.resetForm();

        this.nome = '';
        this.email = '';
        this.senha = '';
        this.confirmarSenha = '';
        this.cpf = '';
        this.telefone = '';

        this.carregando = false;
      },

      error: (erro) => {
        console.error('Erro ao cadastrar cliente:', erro);

        alert('Não foi possível realizar o cadastro.');

        this.carregando = false;
      }

    });
  }
}


import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import { ActivatedRoute, RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

import { Produto } from '../vitrine/produto';
import { Produto as ProdutoApi } from '../services/produto.model';

import { ProdutoService } from '../services/produto.service';
import { Cesta } from '../cesta/cesta';

@Component({
  imports: [CommonModule, RouterLink],
  selector: 'app-detalhe',
  styleUrl: './detalhe.css',
  templateUrl: './detalhe.html',
})
export class Detalhe implements OnInit {

  produto: Produto | null = null;
  carregando: boolean = false;
  mensagem: string = '';

  constructor(
    private route: ActivatedRoute,
    private produtoService: ProdutoService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const codigo = Number(params.get('codigo'));

      if (!Number.isInteger(codigo) || codigo <= 0) {
        this.produto = null;
        this.mensagem = 'Código de produto inválido.';
        this.cdr.markForCheck();
        return;
      }

      this.carregando = true;
      this.produto = null;
      this.mensagem = '';

      this.produtoService.buscar(codigo).subscribe({
        next: (dado: ProdutoApi) => {
          if (!dado || !dado.codigo) {
            this.mensagem = 'Produto não encontrado.';
            this.produto = null;
          } else {
            this.produto = this.converterProduto(dado);
          }

          this.carregando = false;
          this.cdr.markForCheck();
        },

        error: (erro) => {
          console.error('Erro ao buscar produto:', erro);

          this.produto = null;
          this.mensagem = 'Não foi possível carregar os dados do produto.';
          this.carregando = false;

          this.cdr.markForCheck();
        }
      });
    });
  }

  private converterProduto(dado: ProdutoApi): Produto {
    const valorOriginal = Number(dado.valor || 0);
    const valorPromo = Number(dado.valorPromo || 0);

    const emPromocao =
      valorPromo > 0 && valorPromo < valorOriginal;

    const codigo = dado.codigo || 0;
    const imagemInformada = dado.imagem?.trim();

    const imagem = imagemInformada
      ? (
          imagemInformada.startsWith('http') ||
          imagemInformada.startsWith('/')
        )
          ? imagemInformada
          : `/${imagemInformada}`
      : this.obterImagem(codigo);

    return {
      codigo,
      tag: emPromocao
        ? 'PROMOÇÃO'
        : dado.destaque > 0
          ? 'NOVO'
          : null,
      categoria: (dado.categoria || 'PRODUTO').toUpperCase(),
      nome: dado.nome,
      preco_atual: this.formatarPreco(
        emPromocao ? valorPromo : valorOriginal
      ),
      preco_original: emPromocao
        ? this.formatarPreco(valorOriginal)
        : null,
      imagem,
      descricao: dado.descritivo
    };
  }

  private formatarPreco(valor: number): string {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  }

  private obterImagem(codigo: number): string {
    if (codigo >= 1 && codigo <= 8) {
      return `/${codigo}.avif`;
    }

    return '/1.avif';
  }

  adicionarCarrinho(): void {
    if (!this.produto) {
      alert('Produto não carregado!');
      return;
    }

    const produtos: Produto[] = JSON.parse(
      localStorage.getItem('cesta') || '[]'
    );

    const existe = produtos.some(
      p => p.codigo === this.produto!.codigo
    );

    if (!existe) {
      produtos.push(this.produto);
    }

    localStorage.setItem('cesta', JSON.stringify(produtos));
    Cesta.produtos = produtos;

    this.router.navigate(['/cesta']);
  }
}


import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import { RouterLink } from '@angular/router';

import { PedidoService } from '../services/pedido.service';
import { Pedido } from '../services/pedido.model';
import { ProdutoService } from '../services/produto.service';
import { Produto as ProdutoApi } from '../services/produto.model';
import { Produto } from '../vitrine/produto';

registerLocaleData(localePt, 'pt-BR');

@Component({
  imports: [CommonModule, RouterLink],
  selector: 'app-pedidos',
  styleUrl: './pedidos.css',
  templateUrl: './pedidos.html',
})
export class Pedidos implements OnInit {

  pedidos: Pedido[] = [];
  produtosCatalogo: Produto[] = [];

  carregando = true;
  mensagem = '';

  constructor(
    private pedidoService: PedidoService,
    private produtoService: ProdutoService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.carregarCatalogo();
    this.buscarPedidos();
  }

  carregarCatalogo(): void {
    this.produtoService.listar().subscribe({
      next: (dados: ProdutoApi[]) => {
        this.produtosCatalogo = dados.map(dado => {
          const valor = Number(dado.valor || 0);
          const promocional = Number(dado.valorPromo || 0);
          const emPromocao = promocional > 0 && promocional < valor;

          const imagemInformada = dado.imagem?.trim();

          let imagem = imagemInformada
            ? imagemInformada
            : (dado.codigo && dado.codigo >= 1 && dado.codigo <= 8
                ? `/${dado.codigo}.avif`
                : '/1.avif');

          if (
            imagemInformada &&
            !imagemInformada.startsWith('http') &&
            !imagemInformada.startsWith('/')
          ) {
            imagem = `/${imagemInformada}`;
          }

          return {
            codigo: dado.codigo || 0,
            nome: dado.nome,
            descricao: dado.descritivo,
            categoria: (dado.categoria || 'PRODUTO').toUpperCase(),
            imagem,
            preco_atual: this.formatarPreco(
              emPromocao ? promocional : valor
            ),
            preco_original: emPromocao
              ? this.formatarPreco(valor)
              : null,
            tag: emPromocao
              ? 'PROMOÇÃO'
              : dado.destaque > 0
                ? 'NOVO'
                : null
          } as Produto;
        });

        console.log('Catálogo carregado:', this.produtosCatalogo);
        this.cdr.markForCheck();
      },
      error: erro => {
        console.error('Erro ao carregar catálogo:', erro);
      }
    });
  }

  buscarPedidos(): void {
    const dadosCliente = localStorage.getItem('clienteLogado');

    if (!dadosCliente) {
      this.mensagem = 'Você precisa fazer login para visualizar seus pedidos.';
      this.carregando = false;
      return;
    }

    const cliente = JSON.parse(dadosCliente);

    this.pedidoService.listarPorCliente(cliente.codigo).subscribe({
      next: resposta => {

        // Ordena os pedidos do mais antigo para o mais recente
        const pedidosOrdenados = [...(resposta || [])].sort(
          (a, b) =>
            Number(a.codigoPedido) - Number(b.codigoPedido)
        );

        this.pedidos = pedidosOrdenados;

        this.carregando = false;

        console.log('Pedidos recebidos:', resposta);
        console.log('Pedidos do cliente:', this.pedidos);

        this.cdr.markForCheck();
      },
      error: erro => {
        console.error('Erro ao buscar pedidos:', erro);
        this.mensagem = 'Não foi possível carregar seus pedidos.';
        this.carregando = false;
        this.cdr.markForCheck();
      }
    });
  }

  // Número sequencial de exibição, independente do ID do banco
  numeroPedido(index: number): number {
    return index + 1;
  }

  buscarProduto(codigoProduto: number): Produto | undefined {
    return this.produtosCatalogo.find(
      produto => Number(produto.codigo) === Number(codigoProduto)
    );
  }

  formatarPreco(valor: number): string {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  }

  formatarData(data: string): string {
    return data.substring(0, 10).split('-').reverse().join('/');
  }
}
